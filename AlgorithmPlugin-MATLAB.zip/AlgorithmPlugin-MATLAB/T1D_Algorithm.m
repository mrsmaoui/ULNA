classdef T1D_Algorithm

    properties
        % Input values for initial conditions
        simulationDuration; % Total time in integer hours 
        timeStep; % (min)
        startHour; glucoseLevel; 
        previousMealTime; previousMealAmount; previousBolusTime; previousBolusAmount;
        TotalInsulinDailyDose, ICR_breakfast, ICR_lunch, ICR_dinner, ICR_overnight, 
        basal_rates    % This is an array of 48 values. The first value is the basal rate at midnight 0:00
                       % the second value is the basal rate at 0:30, followed by 1:00, 1:30, 2:00 ...
                       % and the last value is the basal rate at 23:30
                       
        
        % Input values for simulateStep command
        time; CHO; exercise;
        
        % Output values of algorithm for simulateStep command
        insulin_basal; insulin_bolus; glucagon_basal; glucagon_bolus;
    end
    
    methods
        % Constructor (do not modify)
        function [self] = T1D_Algorithm()
        end
 
        function self = initialConditions(self, simulationDuration, timeStep, startHour, glucoseLevel, previousMealTime, previousMealAmount, previousBolusTime, previousBolusAmount,TotalInsulinDailyDose, ICR_breakfast, ICR_lunch, ICR_dinner, ICR_overnight, basal_rates)
            
            self.simulationDuration = simulationDuration;
            self.timeStep = timeStep;
            self.startHour = startHour;
            self.glucoseLevel = glucoseLevel;
            self.previousMealTime = previousMealTime;
            self.previousMealAmount = previousMealAmount;
            self.previousBolusTime = previousBolusTime;
            self.previousBolusAmount = previousBolusAmount;
            self.TotalInsulinDailyDose = TotalInsulinDailyDose;
            self.ICR_breakfast = ICR_breakfast;
            self.ICR_lunch = ICR_lunch;
            self.ICR_dinner = ICR_dinner;
            self.ICR_overnight = ICR_overnight;
            self.basal_rates = basal_rates;
            
            % FILL IN YOUR CODE HERE
        end
            
        function [self, insulinBasal, insulinBolus, glucagonBasal, glucagonBolus] = simulateStep(self, time, glucoseLevel, CHO, exercise)
            % time is in hours and is incremented timeStep min. 

            self.time = time;
            self.glucoseLevel = glucoseLevel;
            self.CHO = CHO;
            self.exercise = exercise;
            
            % FILL IN YOUR DEVELOPMENT CODE HERE
            
            % Generate output
            insulinBasal = (glucoseLevel - 6) * 0.2 +0.5 ;
            insulinBasal = max(insulinBasal, 0);
            self.insulin_basal = insulinBasal;
            
            
            insulinBolus = 0.0;
            if(CHO ~= 0)
                insulinBolus = CHO/10.0;
            end
            
            self.insulin_bolus = insulinBolus;
            
            glucagonBasal = 0.0;
            self.glucagon_basal = glucagonBasal;
            
            glucagonBolus = 0.0;
            if(glucoseLevel < 5)
                glucagonBolus = (5-glucoseLevel) * 2;
            end
            self.glucagon_bolus = glucagonBolus;
            
            % END OF DEVELOPMENT CODE
        end
    end
    
end

