package algorithm;

public class PID implements T1D_Algorithm{

	double ICR_breakfast;
	double ICR_lunch;
	double ICR_dinner;
    double ICR_overnight;
    double startHour;
    
    
    
	@Override
	public void setInitialConditions(int simulationDuration, int timeStep, int startHour, double glucoseLevel, 
            int previousMealTime, double previousMealAmount, int previousBolusTime, double previousBolusAmount,
            double TotalInsulinDailyDose, double ICR_breakfast, double ICR_lunch, double ICR_dinner,
            double ICR_overnight, double[] basal_rates) {
		// TODO Auto-generated method stub
		
		this.ICR_breakfast = ICR_breakfast;
		this.ICR_lunch = ICR_lunch;
		this.ICR_dinner = ICR_dinner;
		this.ICR_overnight = ICR_overnight;
		this.startHour = startHour;
	}
	
	
	@Override
	public Result controlStep(double currentTime, double glucoseLevel, double CHO, boolean exercise) {

		double insulin_basal = 0.0;
		double insulin_bolus = 0.0;
		double glucagon_basal = 0.0;
		double glucagon_bolus = 0.0;
				
        insulin_basal = (glucoseLevel - 6) * 0.2 + 0.5 ;
        insulin_basal = Math.max(insulin_basal, 0);
        insulin_basal = 0.345077803;
        
        insulin_bolus = 0.0;
        if(CHO != 0){
            double actualTime = (currentTime + startHour) % 24.0;
            
	        if(actualTime >= 6 && actualTime <= 11){ //breakfast
                insulin_bolus = (ICR_breakfast / 10.0) * CHO;
	        }
	        else if(actualTime > 11 && actualTime <= 17){ //lunch
                insulin_bolus = (ICR_lunch / 10.0) * CHO;
	        }
	        else if(actualTime > 17 && actualTime <= 23){ //dinner
                insulin_bolus = (ICR_dinner / 10.0) * CHO;
	        }
	        else { //overnight
                insulin_bolus = (ICR_overnight / 10.0) * CHO;
            }
        }
        //insulin_bolus = 0;
        
        glucagon_bolus = 0.0;
        if(glucoseLevel < 5){
            glucagon_bolus = (5.5-glucoseLevel) * 2;
            glucagon_bolus = 0;
		    
        }
        
        Result result = new Result(insulin_basal, insulin_bolus, glucagon_basal, glucagon_bolus);

        return result;
	}





}