package algorithm;

public class OpenLoop implements T1D_Algorithm{

	@Override
	public void setInitialConditions(int simulationDuration, int timeStep, int startHour, double glucoseLevel, 
            int previousMealTime, double previousMealAmount, int previousBolusTime, double previousBolusAmount,
            double TotalInsulinDailyDose, double ICR_breakfast, double ICR_lunch, double ICR_dinner,
            double ICR_overnight, double[] basal_rates) {
		// TODO Auto-generated method stub
		
	}
	
	
	@Override
	public Result controlStep(double currentTime, double glucoseLevel, double CHO, boolean exercise) {

		double insulin_basal = 1.3;
		double insulin_bolus = 0.0;
		double glucagon_basal = 0.0;
		double glucagon_bolus = 0.0;
				
		Result result = new Result(insulin_basal, insulin_bolus, glucagon_basal, glucagon_bolus);

		return result;
		
	}

	

}
