package algorithm;

public class StartSimulation {
	static int port = 3282; //default port 3282
	
	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException{
				
		// Instantiate your controller. Make sure it implements the T1D_Algorithm interface
		T1D_Algorithm controller = new PID();
		
		// Connect to simulation environment. Connect before starting the simulation run in ULNA
		Nexus connection = new Nexus(controller, port);
		connection.begin();
		
	}
}



