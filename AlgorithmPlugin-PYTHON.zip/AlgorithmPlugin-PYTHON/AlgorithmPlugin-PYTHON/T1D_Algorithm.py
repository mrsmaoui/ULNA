class T1D_Algorithm(object):

    def initialConditions(self, simulationDuration, timeStep, startHour, glucoseLevel, previousMealTime, 
        previousMealAmount, previousBolusTime, previousBolusAmount,TotalInsulinDailyDose, ICR_breakfast, 
        ICR_lunch, ICR_dinner, ICR_overnight, basal_rates):
        
        self.simulationDuration = simulationDuration
        self.timeStep = timeStep
        self.startHour = startHour
        self.glucoseLevel = glucoseLevel
        self.previousMealTime = previousMealTime
        self.previousMealAmount = previousMealAmount
        self.previousBolusTime = previousBolusTime
        self.previousBolusAmount = previousBolusAmount
        self.TotalInsulinDailyDose = TotalInsulinDailyDose
        self.ICR_breakfast = ICR_breakfast
        self.ICR_lunch = ICR_lunch
        self.ICR_dinner = ICR_dinner
        self.ICR_overnight = ICR_overnight
        self.basal_rates = basal_rates      # This is an array of 48 values. The first value is the basal rate at midnight 0:00
                                            # the second value is the basal rate at 0:30, followed by 1:00, 1:30, 2:00 ...
                                            # and the last value is the basal rate at 23:30
        # FILL IN YOUR CODE HERE
        # ...
        # ...
        # ...
        # END OF YOUR CODE HERE
                          
    def controlStep(self, time, glucoseLevel, CHO, exercise): # time is in hours and is incremented by timeStep min. 

        # FILL IN YOUR DEVELOPMENT CODE HERE -- SAMPLE CODE PROVIDED

        insulinBasal = (glucoseLevel - 6) * 0.2 +0.5 
        insulinBasal = max(insulinBasal, 0)
                
        insulinBolus = 0.0
        if(CHO != 0):
            insulinBolus = CHO/10.0
                    
        glucagonBasal = 0.0
            
        glucagonBolus = 0.0
        if(glucoseLevel < 5):
           glucagonBolus = (5-glucoseLevel) * 2
        
            
        # END OF DEVELOPMENT CODE

        return insulinBasal, insulinBolus, glucagonBasal, glucagonBolus
        
         

