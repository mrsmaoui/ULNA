"""
CONFIGURATION FILE FOR SETTING THE PATH TO THE PYTHON CONTROLLER ALGORITHM
YOU ONLY HAVE TO MODIFY THE FOLLOWING 2 PARAMETERS:
	- JAR_PROGRAM [line 11]
	- ALGORITHM_FILE [line 12]
"""

import os
import subprocess

JAR_PROGRAM="COMPLETE_PATH_TO_JAR_FILE/NexusCommunicator_PYTHON.jar"
ALGORITHM_FILE="COMPLETE_PATH_TO_ALGORITHM_FILE/T1D_Algorithm.py"
PORT=3282

system_call = "java -jar " + "\"" + JAR_PROGRAM + "\"" + " " + "\"" + ALGORITHM_FILE + "\"" + " " + str(PORT) + "&"
os.system(system_call)

#print subprocess.Popen(system_call, shell=True, stdout=subprocess.PIPE).stdout.read()

